var myaddress = "your public address"
var myprivatekey = "your private key to that address"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.